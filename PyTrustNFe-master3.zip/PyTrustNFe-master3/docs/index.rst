.. PyTrustNFe documentation master file, created by
   sphinx-quickstart on Sun Jun 21 21:14:48 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Bem Vindo ao ``PyTrustNFe``
===========================

``PyTrustNFe`` é uma bilioteca com o propósito de implementar todas 
as comunicações relacionadas a NF-e diretamente com a sefaz.
O objetivo desta biblioteca é prover mais simplicidade e fornecer
uma biblioteca estável com cobertura de código

Installation
------------
Você pode instalar ``PyTrustNFe`` com ``pip``:

.. code-block:: console

    $ pip install PyTrustNFe

Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

