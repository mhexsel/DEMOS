* Barreiras - BA
* Boa Vista - RR
* Bom Jesus da Lapa - BA
* Catu - BA
* Eunápolis - BA
* Ipiaú - BA
* Jacobina - BA
* São Sebastião de Passé - BA
