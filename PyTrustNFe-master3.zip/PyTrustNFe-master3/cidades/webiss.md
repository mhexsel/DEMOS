* Aracajú - SE
* Arcos - MG
* Bagé - RS
* Barbacena - MG
* Brumado - BA.
* Campo Belo - MG
* Candeias - BA
* Cássia - MG
* Caldas Novas - GO
* Coronel Fabriciano - MG
* Estância - SE
* Extrema - MG
* Feira de Santana–BA
* Formiga - MG
* Guanambi - BA
* Itabuna - BA
* Itapetinga - BA
* Lagarto - SE
* Lucas do Rio Verde - MT
* Luís Eduardo Magalhães - BA
* Niterói - RJ
* Nova Serrana - MG
* Palmas - TO
* Passos - MG
* Porto Nacional - TO
* Santa Rita do Sapucai - MG
* São Gotardo - MG
* São Lourenço - MG
* Tangará da Serra - MT  
* Teresópolis - RJ
* Uberaba-MG
* Vitória da Conquista - BA
