* Amparo - SP
* Arapiraca - AL
* Araraquara - SP
* Araxá - MG
* Belford Roxo - RJ
* Betim - MG
* Caraguatatuba - SP
* Caruaru - PE
* Capivari - SP  
* Cataguases - MG
* Cotia - SP
* Diadema - SP
* Eusébio - CE
* Fortaleza - CE
* Franca - SP
* Guaíba - RS
* Guaratinguetá - SP
* Guarujá - SP
* Guarulhos - SP
* Hortolândia - SP
* Itaboraí - RJ
* Itabira - MG
* Itajuba - MG
* Itaúna - MG
* Itu - SP
* Jaboticabal - SP
* Jardinópolis - SP
* Jaú - SP
* Jundiaí - SP
* Lagoa Santa - MG
* Maceió - AL
* Manaus - AM
* Morro Agudo - SP
* Mauá - SP
* Muriaé - MG
* Olímpia - SP
* Paulínia - SP
* Pelotas - RS
* Poços de Caldas - MG
* Porto Ferreira - SP
* Pouso Alegre - MG
* Ribeirão das Neves - MG
* Ribeirão Pires - SP
* Ribeirão Preto - SP
* Rio Claro - SP
* Salto - SP
* Santa Rita do Passa Quatro - SP
* Santo André - SP
* Santos - SP
* São Bernardo do Campo - SP
* São Caetano do Sul - SP
* São Carlos - SP
* São José do Rio Preto - SP
* São José dos Campos - SP
* São Roque - SP
* Sarzedo - MG
* Suzano - SP
* Taquaritinga - SP
* Ubá - MG
* Ubatuba - SP
* Umuarama - PR
* Votuporanga - SP
