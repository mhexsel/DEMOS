* Belém - PA
* Sorocaba - SP
* Teresina - PI
* Campinas - SP
* Uberlandia - MG
* São Luis - MA
* Campo Grande - MS
